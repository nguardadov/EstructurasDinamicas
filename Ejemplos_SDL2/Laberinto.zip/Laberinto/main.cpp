/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: nelso
 *
 * Created on 9 de noviembre de 2017, 20:49
 */
#include <iostream>
#include <cstdlib>
#include "interfaz.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Ventana v;
    v.IniciarVentana();
    return 0;
}

