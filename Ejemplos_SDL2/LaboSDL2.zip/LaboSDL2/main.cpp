#include <iostream>
#include <cstdlib>
#include "interfaz.h"
using namespace std;
int main(int argc, char** argv) {
    Ventana v;
    v.correrJuego();
    return 0;
}

